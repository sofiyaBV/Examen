#include "Test.h"
using namespace std;

void main()
{
	setlocale(LC_CTYPE, "ukr");
	Testing_system a;
	a.menu();
		system("pause");		
}
